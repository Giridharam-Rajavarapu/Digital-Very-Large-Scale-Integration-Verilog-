module halfsub_tb();
reg A,B; wire DIFFERENCE, BORROW;
halfsub uut(.A(A),.B(B),.DIFFERENCE(DIFFERENCE),.BORROW(BORROW));

initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0,halfsub_tb);
    $monitor($time,"A=%b B=%b DIFFERENCE=%bBORROW=%b",A,B,DIFFERENCE,BORROW);

    A=0; B=0; #10;
    A=0; B=1; #10;
    A=1; B=0; #10;
    A=1; B=1; #10;
$finish;
end
endmodule