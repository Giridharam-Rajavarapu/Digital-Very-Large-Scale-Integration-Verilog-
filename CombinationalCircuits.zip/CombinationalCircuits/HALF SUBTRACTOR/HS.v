module halfsub(input A,B,output reg DIFFERENCE, BORROW);
always@(*) begin
              DIFFERENCE=A^B;
              BORROW=(~A)&B;
end 
endmodule