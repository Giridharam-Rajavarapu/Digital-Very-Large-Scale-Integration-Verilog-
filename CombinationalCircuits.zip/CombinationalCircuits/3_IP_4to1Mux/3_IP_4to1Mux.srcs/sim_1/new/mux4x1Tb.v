`timescale 1ns/1ps

module mux4x1Tb;

reg A,B,C;
wire F;

mux4x1 uut(
    .A(A),
    .B(B),
    .C(C),
    .F(F)
);

initial
begin
    $display("A B C | F");
    $monitor("%b %b %b | %b", A,B,C,F);

    A=0; B=0; C=0; #10;
    A=0; B=0; C=1; #10;
    A=0; B=1; C=0; #10;
    A=0; B=1; C=1; #10;
    A=1; B=0; C=0; #10;
    A=1; B=0; C=1; #10;
    A=1; B=1; C=0; #10;
    A=1; B=1; C=1; #10;

    $finish;
end

endmodule