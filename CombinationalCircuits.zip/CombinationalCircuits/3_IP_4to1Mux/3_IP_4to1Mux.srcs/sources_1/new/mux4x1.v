`timescale 1ns / 1ps

module mux4x1(
input A,B,C,
output reg F
    );
always@(*)
begin
      case({A,B})
           2'b00 :F= C;
           2'b01 :F= ~C;
           2'b10 :F=1'b0;
           2'b11 :F= 1'b1;
           default :F=1'b0;
       endcase
 end
           
endmodule
