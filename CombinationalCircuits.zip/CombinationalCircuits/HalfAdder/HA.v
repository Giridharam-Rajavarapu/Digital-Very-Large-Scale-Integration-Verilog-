module halfadder(input A,B,output reg SUM, CARRY);
always@(*) begin
               SUM=A^B;
               CARRY=A&B;
end 
endmodule