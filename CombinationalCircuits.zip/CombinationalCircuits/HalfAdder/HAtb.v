module halfadder_tb();
reg A,B; wire SUM, CARRY;
halfadder uut(.A(A),.B(B),.SUM(SUM),.CARRY(CARRY));

initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0,halfadder_tb);
    $monitor($time,"A=%b B=%b SUM=%b CARRY=%b",A,B,SUM,CARRY);

    A=0; B=0; #10;
    A=0; B=1; #10;
    A=1; B=0; #10;
    A=1; B=1; #10;
$finish;
end
endmodule