`timescale 1ns/1ps

module priority_encoder4to2_tb;

reg [3:0] D;
wire [1:0] Y;

priority_encoder4to2 uut(
    .D(D),
    .Y(Y)
);

initial
begin
    $monitor("Time=%0t D=%b Y=%b",$time,D,Y);

    D = 4'b0001; #10;
    D = 4'b0010; #10;
    D = 4'b0100; #10;
    D = 4'b1000; #10;

    D = 4'b1010; #10; // D3 priority
    D = 4'b0110; #10; // D2 priority
    D = 4'b1111; #10; // D3 priority

    $finish;
end

endmodule