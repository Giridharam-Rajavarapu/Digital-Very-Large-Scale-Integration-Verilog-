module t3to8dec(A, O);
input  [2:0] A;
output reg [7:0] O;

always @(*) begin
    case (A)
        3'b000: O = 8'b0000_0001;
        3'b001: O = 8'b0000_0010;
        3'b010: O = 8'b0000_0100;
        3'b011: O = 8'b0000_1000;
        3'b100: O = 8'b0001_0000;
        3'b101: O = 8'b0010_0000;
        3'b110: O = 8'b0100_0000;
        3'b111: O = 8'b1000_0000;
        default: O = 8'b0000_0000;
    endcase
end

endmodule
