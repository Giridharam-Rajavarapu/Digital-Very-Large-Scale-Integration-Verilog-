`timescale 1ns/1ps

module t3to8dec_tb;

    reg  [2:0] A;
    wire [7:0] O;

    // Instantiate the decoder
    t3to8dec uut (
        .A(A),
        .O(O)
    );

    initial begin

        $dumpfile("t3to8dec.vcd");
        $dumpvars(0, t3to8dec_tb);

        $monitor("Time=%0t | A=%b | O=%b", $time, A, O);

        // Apply test vectors
        A = 3'b000; #5;
        A = 3'b001; #5;
        A = 3'b010; #5;
        A = 3'b011; #5;
        A = 3'b100; #5;
        A = 3'b101; #5;
        A = 3'b110; #5;
        A = 3'b111; #5;

        $finish;
    end

endmodule
