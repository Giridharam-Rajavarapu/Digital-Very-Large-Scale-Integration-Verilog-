
module t8to3_tb;

    reg  [7:0] D;
    wire [2:0] O;

    t8t03en uut (.D(D),.O(O));

    initial begin
        
        $dumpfile("t8to3en.vcd");
        $dumpvars(0, t8to3_tb);

        
        $monitor("Time=%0t | D=%b | O=%b", $time, D, O);

      
        D = 8'b0000_0001; #5;
        D = 8'b0000_1000; #5;
        D = 8'b0001_0000; #5;
        D = 8'b1000_0000; #5;
        D = 8'b0000_0000; #5;

        $finish;
    end

endmodule
