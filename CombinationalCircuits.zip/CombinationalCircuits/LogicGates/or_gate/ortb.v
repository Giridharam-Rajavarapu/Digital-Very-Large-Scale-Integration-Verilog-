module or_tb;
  reg a, b;
  wire y;

  or_gate uut (.a(a), .b(b), .y(y));

  initial begin
    $monitor($time,"A=%b B=%b C=%b",a,b,y);
    $dumpfile("or.vcd");
    $dumpvars(0, or_tb);

    a=0; b=0; #10;
    a=0; b=1; #10;
    a=1; b=0; #10;
    a=1; b=1; #10;

    $finish;
  end
endmodule
