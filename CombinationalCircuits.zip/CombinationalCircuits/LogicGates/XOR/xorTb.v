`timescale 1ns / 1ps

module XOR4_tb;

reg [3:0] A;
reg [3:0] B;

wire [3:0] Y;

XOR4 uut(
    .A(A),
    .B(B),
    .Y(Y)
);

initial
begin

    $monitor("Time=%0t A=%b B=%b XOR=%b",
              $time,A,B,Y);

    A = 4'b0110;   // 6
    B = 4'b0100;   // 4
    #10;

    A = 4'b1010;   // 10
    B = 4'b1100;   // 12
    #10;

    A = 4'b1111;   // 15
    B = 4'b0000;   // 0
    #10;

    A = 4'b1111;
    B = 4'b1111;
    #10;

    $finish;

end

endmodule