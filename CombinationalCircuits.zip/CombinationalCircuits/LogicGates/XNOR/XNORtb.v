module xnor_tb;
  reg a, b;
  wire y;

  xnor_gate uut (.a(a), .b(b), .y(y));

  initial begin
    $monitor($time, " A=%b B=%b Y=%b", a, b, y);
    $dumpfile("xnor.vcd");
    $dumpvars(0, xnor_tb);

    a = 0; b = 0; #10;
    a = 0; b = 1; #10;
    a = 1; b = 0; #10;
    a = 1; b = 1; #10;

    $finish;
  end
endmodule