module andtb;
  reg a, b;
  wire y;

  andv uut (.a(a), .b(b), .y(y));

  initial begin
    $monitor($time,"a=%b b=%b y=%b",a,b,y);
    $dumpfile("andv.vcd");
    $dumpvars(0, andtb);

    a=0; b=0; #10;
    a=0; b=1; #10;
    a=1; b=0; #10;
    a=1; b=1; #10;

    $finish;
  end
endmodule
