`timescale 1ns / 1ps

module andv(a, b, y );
    input a, b;
    output reg y;
    always@(*)
     begin
       y=a&b;
      end
   endmodule
