module fulladder(input A,B,C,output reg SUM, CARRY);
always@(*) begin
               SUM=A^B^C;
               CARRY=(A&B)|(C&A)|(C&B);
end 
endmodule