module fulladder_tb();
reg A,B,C; wire SUM, CARRY;
fulladder uut(.A(A),.B(B),.C(C),.SUM(SUM),.CARRY(CARRY));

initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0,fulladder_tb);
    $monitor($time,"A=%b B=%b C=%b SUM=%b CARRY=%b",A,B,C,SUM,CARRY);

    A=0; B=0; C=0;    #10;
    A=0; B=0; C=1;    #10;
    A=0; B=1; C=0;  #10;
    A=0; B=1; C=1;  #10;
    A=1; B=0; C=0;    #10;
    A=1; B=0; C=1;   #10;
    A=1; B=1; C=0;  #10;
    A=1; B=1; C=1;  #10;
$finish;
end
endmodule