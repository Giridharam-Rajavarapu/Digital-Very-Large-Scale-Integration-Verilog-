`timescale 1ns/1ps

module even_parity_checker_tb;

reg [3:0] data;
reg parity;
wire error;

even_parity_checker uut(
    .data(data),
    .parity(parity),
    .error(error)
);

initial
begin
    $display("Data\tParity\tError");
    $monitor("%b\t%b\t%b", data, parity, error);

    // Correct parity
    data = 4'b0000; parity = 0; #10;
    data = 4'b0001; parity = 1; #10;
    data = 4'b0011; parity = 0; #10;

    // Incorrect parity
    data = 4'b0001; parity = 0; #10;
    data = 4'b1111; parity = 1; #10;

    $finish;
end

endmodule