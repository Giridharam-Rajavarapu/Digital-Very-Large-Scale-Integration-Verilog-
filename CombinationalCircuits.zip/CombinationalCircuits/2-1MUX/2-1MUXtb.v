module mux2to1_tb();
reg A, B, S;
wire Y;

mux2to1 uut(.A(A), .B(B), .S(S), .Y(Y));

initial begin
    $dumpfile("mux.vcd");
    $dumpvars(0, mux2to1_tb);
    $monitor($time," A=%b B=%b S=%b | Y=%b", A, B, S, Y);

    A=0; B=0; S=0; #10;
    A=0; B=1; S=0; #10;
    A=1; B=0; S=0; #10;
    A=1; B=1; S=0; #10;

    A=0; B=0; S=1; #10;
    A=0; B=1; S=1; #10;
    A=1; B=0; S=1; #10;
    A=1; B=1; S=1; #10;

    $finish;
end
endmodule

/*module mux4to1_tb;

reg A,B,C,D;
reg S1,S0;
wire Y;

mux4to1_df uut(
    .A(A),
    .B(B),
    .C(C),
    .D(D),
    .S1(S1),
    .S0(S0),
    .Y(Y)
);

initial
begin
    A=1; B=0; C=1; D=0;

    S1=0; S0=0; #10;
    S1=0; S0=1; #10;
    S1=1; S0=0; #10;
    S1=1; S0=1; #10;

    $finish;
end

endmodule
