module fullsub_tb();
reg A,B,C; wire DIFFERENCE, BORROW;
fullsub uut(.A(A),.B(B),.C(C),. DIFFERENCE( DIFFERENCE),.BORROW(BORROW));

initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0,fullsub_tb);
    $monitor($time,"A=%b B=%b C=%b  DIFFERENCE=%b BORROW=%b",A,B,C, DIFFERENCE,BORROW);

    A=0; B=0; C=0;    #10;
    A=0; B=0; C=1;    #10;
    A=0; B=1; C=0;  #10;
    A=0; B=1; C=1;  #10;
    A=1; B=0; C=0;    #10;
    A=1; B=0; C=1;   #10;
    A=1; B=1; C=0;  #10;
    A=1; B=1; C=1;  #10;
$finish;
end
endmodule