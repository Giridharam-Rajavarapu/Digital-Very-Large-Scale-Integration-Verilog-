module fullsub(input A,B,C, output reg DIFFERENCE, BORROW);
always@(*) begin
              DIFFERENCE=A^B^C;
              BORROW=((~A)&B)|C&(~(A^B));
end 
endmodule