`timescale 1ns / 1ps

module even_parity_generator_tb;

reg data;
wire parity;

even_parity_generator uut(.data(data),.parity(parity));

initial
begin

$display("Data\tparity");
$monitor("%b\t%b", data, parity);

data=4'b0000; #5;
data=4'b0001; #5;
data=4'b0011; #5;
data=4'b0111; #5;
data=4'b1111; #5;

$finish;

end
endmodule
