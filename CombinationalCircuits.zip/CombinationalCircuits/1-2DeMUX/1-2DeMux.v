module demux1to2(
    input D,
    input S,
    output Y0, Y1
);
assign Y0 = (~S) & D;
assign Y1 = ( S) & D;
endmodule


/*module demux1to2(
    input D,
    input S,
    output reg Y0, Y1
);

always @(*)
begin
    Y0 = 0;
    Y1 = 0;

    if(S == 0)
        Y0 = D;
    else
        Y1 = D;
end

endmodule

module demux1to4(
    input D,
    input [1:0] S,
    output reg Y0, Y1, Y2, Y3
);

always @(*)
begin
    Y0=0; Y1=0; Y2=0; Y3=0;

    case(S)
        2'b00: Y0 = D;
        2'b01: Y1 = D;
        2'b10: Y2 = D;
        2'b11: Y3 = D;
    endcase
end

endmodule