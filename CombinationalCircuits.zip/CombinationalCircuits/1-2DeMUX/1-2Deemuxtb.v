module demux1to2_tb();
reg D, S;
wire Y0, Y1;

demux1to2 uut(.D(D), .S(S), .Y0(Y0), .Y1(Y1));

initial begin
    $dumpfile("demux.vcd");
    $dumpvars(0, demux1to2_tb);
    $monitor($time," D=%b S=%b | Y0=%b Y1=%b", D, S, Y0, Y1);

    D=0; S=0; #10;
    D=1; S=0; #10;
    D=0; S=1; #10;
    D=1; S=1; #10;

    $finish;
end
endmodule

/*module decoder1to4 (
    input A,
    input B,
    output reg [3:0] Y
);

always @(*) begin
    case ({A, B})
        2'b00: Y = 4'b0001;
        2'b01: Y = 4'b0010;
        2'b10: Y = 4'b0100;
        2'b11: Y = 4'b1000;
        default: Y = 4'b0000;
    endcase
end

endmodule
*/